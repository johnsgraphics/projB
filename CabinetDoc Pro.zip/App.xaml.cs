﻿using System.Windows;

namespace CabinetDocProWpf
{
    public partial class App : Application
    {
    }
}
