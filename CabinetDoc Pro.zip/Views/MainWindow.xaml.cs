﻿// filename: F:\CabinetDoc Pro\Views\MainWindow.xaml.cs
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using CabinetDocProWpf.Views.Pages;

namespace CabinetDocProWpf.Views
{
    public partial class MainWindow : Window
    {
        private bool isCollapsed = false;

        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new DashboardPage());
        }

        private void ToggleButton_Click(object sender, RoutedEventArgs e)
        {
            // Create fade animation for smooth visual effect
            DoubleAnimation opacityAnimation = new DoubleAnimation
            {
                Duration = TimeSpan.FromMilliseconds(200),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseInOut }
            };

            if (isCollapsed)
            {
                // Expand sidebar to 240px
                SidebarColumn.Width = new GridLength(240);

                // Show text labels with fade-in
                opacityAnimation.From = 0;
                opacityAnimation.To = 1;

                TxtDashboard.Visibility = Visibility.Visible;
                TxtCreate.Visibility = Visibility.Visible;
                TxtClients.Visibility = Visibility.Visible;
                TxtDocuments.Visibility = Visibility.Visible;
                TxtSettings.Visibility = Visibility.Visible;

                TxtDashboard.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                TxtCreate.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                TxtClients.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                TxtDocuments.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
                TxtSettings.BeginAnimation(UIElement.OpacityProperty, opacityAnimation);
            }
            else
            {
                // Collapse sidebar to 60px
                SidebarColumn.Width = new GridLength(70);

                // Hide text labels
                TxtDashboard.Visibility = Visibility.Collapsed;
                TxtCreate.Visibility = Visibility.Collapsed;
                TxtClients.Visibility = Visibility.Collapsed;
                TxtDocuments.Visibility = Visibility.Collapsed;
                TxtSettings.Visibility = Visibility.Collapsed;
            }

            isCollapsed = !isCollapsed;
        }

        private void BtnDashboard_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new DashboardPage());
            SetActive(BtnDashboard);
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new DocumentCreationPage());
            SetActive(BtnCreate);
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new ClientsPage());
            SetActive(BtnClients);
        }

        private void BtnDocuments_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new DocumentPreviewPage());
            SetActive(BtnDocuments);
        }

        private void BtnSettings_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new SettingsPage());
            SetActive(BtnSettings);
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Fonctionnalité d'exportation à venir.", "Exporter", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BtnNew_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new DocumentCreationPage());
            SetActive(BtnCreate);
        }

        private void SetActive(Button activeButton)
        {
            // Clear all active tags
            BtnDashboard.Tag = null;
            BtnCreate.Tag = null;
            BtnClients.Tag = null;
            BtnDocuments.Tag = null;
            BtnSettings.Tag = null;

            // Set active tag on clicked button
            activeButton.Tag = "Active";
        }
    }
}
