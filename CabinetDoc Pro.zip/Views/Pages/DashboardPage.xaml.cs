﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace CabinetDocProWpf.Views.Pages
{
    public partial class DashboardPage : Page
    {
        public DashboardPage()
        {
            InitializeComponent();
        }

        // زر إنشاء وثيقة جديدة
        private void BtnCreateDocument_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new DocumentCreationPage());
        }

        // زر إدارة العملاء
        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new ClientsPage());
        }

        // زر المكتبة (الوثائق)
        private void BtnDocuments_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.Navigate(new DocumentPreviewPage());
        }

        // رابط "Voir tous" في KPI
        private void BtnViewClients_Click(object sender, MouseButtonEventArgs e)
        {
            NavigationService?.Navigate(new ClientsPage());
        }
    }
}
