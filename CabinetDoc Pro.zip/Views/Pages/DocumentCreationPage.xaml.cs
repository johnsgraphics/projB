﻿// filename: F:\CabinetDoc Pro\Views\Pages\DocumentCreationPage.xaml.cs
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CabinetDocProWpf.Models;
using CabinetDocProWpf.Services;

namespace CabinetDocProWpf.Views.Pages
{
    public partial class DocumentCreationPage : Page
    {
        private readonly DataService _dataService = new DataService();
        private readonly SettingsService _settingsService = new SettingsService();
        private readonly ClientsLocalService _clientsService = new ClientsLocalService();
        private string _documentType = "NOTE_HONORAIRES";
        private string _selectedClientId = "";
        private string _selectedTheme = "BlueWave";
        private DocumentModel _currentDocument;
        private FirmSettings _firmSettings;
        private readonly ObservableCollection<Client> _clients = new ObservableCollection<Client>();
        private readonly SolidColorBrush _cDark = new SolidColorBrush(Color.FromRgb(23, 52, 61));
        private readonly SolidColorBrush _cTeal = new SolidColorBrush(Color.FromRgb(0, 166, 164));
        private readonly SolidColorBrush _cGray = new SolidColorBrush(Color.FromRgb(107, 114, 128));
        private readonly SolidColorBrush _cBorder = new SolidColorBrush(Color.FromRgb(216, 222, 233));

        public DocumentCreationPage()
        {
            InitializeComponent();
            _firmSettings = _settingsService.GetFirmSettings();
            LoadClients();
            InitializeDocumentModels();
            this.Loaded += (s, e) =>
            {
                RenderFormForDocumentType();
                RedrawPreview();
            };
        }

        private void InitializeDocumentModels()
        {
            _currentDocument = new DocumentModel
            {
                Type = "NOTE_HONORAIRES",
                DocumentNumber = "01/2025/HN",
                IssueDate = DateTime.Today,
                DueDate = DateTime.Today.AddDays(30),
                ServicePeriod = "Janvier 2025",
                ClientId = "",
                Theme = "BlueWave",
                TvaRate = 0m,
                PaymentTerms = "Paiement à 30 jours",
                Notes = "",
                LineItems = new List<LineItem>
                {
                    new LineItem
                    {
                        Description = "TRAVAUX D'AUGMENTATION CAPITAL",
                        Quantity = 1,
                        UnitPrice = 50000
                    }
                }
            };
        }

        private void LoadClients()
        {
            var list = _clientsService.LoadClients();
            _clients.Clear();
            foreach (var c in list)
                _clients.Add(c);

            CmbClient.ItemsSource = _clients;

            if (_clients.Any())
            {
                CmbClient.SelectedIndex = 0;
                _selectedClientId = _clients.First().Id.ToString();
            }
        }

        private void RenderFormForDocumentType()
        {
            if (FormContentPanel == null) return;

            FormContentPanel.Children.Clear();

            if (_documentType == "NOTE_HONORAIRES")
                FormContentPanel.Children.Add(BuildNoteForm());
            else
                FormContentPanel.Children.Add(BuildRapportForm());
        }

        private UIElement BuildNoteForm()
        {
            var root = new StackPanel();
            root.Children.Add(MakeFormLabel("Détails de la Note d'Honoraires"));

            var txtDocNum = new TextBox
            {
                Text = _currentDocument.DocumentNumber,
                Height = 40,
                Padding = new Thickness(12, 0, 12, 0),
                Tag = "DocumentNumber"
            };
            txtDocNum.TextChanged += FormField_Changed;

            var dpIssue = new DatePicker
            {
                SelectedDate = _currentDocument.IssueDate,
                Height = 40,
                Tag = "IssueDate"
            };
            dpIssue.SelectedDateChanged += FormField_Changed;

            root.Children.Add(RowTwo(
                Labeled("Numéro de Document *", txtDocNum),
                Labeled("Date d'émission", dpIssue)
            ));

            var dpDue = new DatePicker
            {
                SelectedDate = _currentDocument.DueDate,
                Height = 40,
                Tag = "DueDate"
            };
            dpDue.SelectedDateChanged += FormField_Changed;

            var txtPeriod = new TextBox
            {
                Text = _currentDocument.ServicePeriod,
                Height = 40,
                Padding = new Thickness(12, 0, 12, 0),
                Tag = "ServicePeriod"
            };
            txtPeriod.TextChanged += FormField_Changed;

            root.Children.Add(RowTwo(
                Labeled("Date d'échéance", dpDue),
                Labeled("Période de service", txtPeriod)
            ));

            root.Children.Add(new TextBlock
            {
                Text = "Services",
                FontSize = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = Brushes.Black,
                Margin = new Thickness(0, 16, 0, 8)
            });

            foreach (var li in _currentDocument.LineItems)
                root.Children.Add(BuildLineItemControl(li));

            var btnAdd = new Button
            {
                Content = "+ Ajouter une ligne",
                Padding = new Thickness(16, 10, 16, 10),
                Margin = new Thickness(0, 8, 0, 8),
                Background = new SolidColorBrush(Color.FromRgb(240, 240, 240)),
                BorderBrush = _cBorder,
                Cursor = System.Windows.Input.Cursors.Hand
            };
            btnAdd.Click += (s, e) =>
            {
                _currentDocument.LineItems.Add(new LineItem
                {
                    Description = "",
                    Quantity = 1,
                    UnitPrice = 0
                });
                RenderFormForDocumentType();
                RedrawPreview();
            };
            root.Children.Add(btnAdd);

            var txtTva = new TextBox
            {
                Text = _currentDocument.TvaRate.ToString("0"),
                Height = 40,
                Padding = new Thickness(12, 0, 12, 0),
                Tag = "TvaRate"
            };
            txtTva.TextChanged += FormField_Changed;

            var txtPayment = new TextBox
            {
                Text = _currentDocument.PaymentTerms,
                Height = 40,
                Padding = new Thickness(12, 0, 12, 0),
                Tag = "PaymentTerms"
            };
            txtPayment.TextChanged += FormField_Changed;

            root.Children.Add(RowTwo(
                Labeled("Taux TVA (%)", txtTva),
                Labeled("Conditions de paiement", txtPayment)
            ));

            var txtNotes = new TextBox
            {
                Text = _currentDocument.Notes,
                Height = 96,
                AcceptsReturn = true,
                TextWrapping = TextWrapping.Wrap,
                Padding = new Thickness(12, 10, 12, 10),
                Tag = "Notes"
            };
            txtNotes.TextChanged += FormField_Changed;

            root.Children.Add(Labeled("Notes additionnelles", txtNotes));
            return root;
        }

        private UIElement BuildRapportForm()
        {
            var root = new StackPanel();
            root.Children.Add(MakeFormLabel("Rapport Spécial - Augmentation du Capital"));

            var txtReportNum = new TextBox
            {
                Text = "01/2025/RP",
                Height = 40,
                Padding = new Thickness(12, 0, 12, 0)
            };

            var dpReport = new DatePicker
            {
                SelectedDate = DateTime.Today,
                Height = 40
            };

            root.Children.Add(RowTwo(
                Labeled("Numéro de Rapport *", txtReportNum),
                Labeled("Date du Rapport", dpReport)
            ));

            var txtMission = new TextBox
            {
                Text = "Augmentation du capital social",
                Height = 40,
                Padding = new Thickness(12, 0, 12, 0)
            };

            var txtAmount = new TextBox
            {
                Text = "200000000",
                Height = 40,
                Padding = new Thickness(12, 0, 12, 0)
            };

            root.Children.Add(RowTwo(
                Labeled("Objet de la Mission", txtMission),
                Labeled("Montant (DA)", txtAmount)
            ));

            root.Children.Add(new TextBlock
            {
                Text = "Le rapport complet sera généré dans le preview.",
                FontSize = 11,
                Foreground = _cGray,
                Margin = new Thickness(0, 16, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });

            return root;
        }

        private Border BuildLineItemControl(LineItem item)
        {
            var b = new Border
            {
                Background = (Brush)new BrushConverter().ConvertFrom("#F9FAFB")!,
                BorderBrush = _cBorder,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12),
                Margin = new Thickness(0, 0, 0, 10)
            };

            var g = new Grid();
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(10) });
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var txtDesc = new TextBox
            {
                Text = item.Description,
                Height = 38,
                Padding = new Thickness(10, 0, 10, 0),
                Tag = item
            };
            txtDesc.TextChanged += (s, e) =>
            {
                item.Description = txtDesc.Text;
                RedrawPreview();
            };

            var desc = Labeled("Description", txtDesc);
            Grid.SetRow(desc, 0);
            g.Children.Add(desc);

            var row = new Grid();
            row.ColumnDefinitions.Add(new ColumnDefinition());
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
            row.ColumnDefinitions.Add(new ColumnDefinition());
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
            row.ColumnDefinitions.Add(new ColumnDefinition());

            var txtQty = new TextBox
            {
                Text = item.Quantity.ToString(),
                Height = 38,
                Padding = new Thickness(10, 0, 10, 0)
            };
            txtQty.TextChanged += (s, e) =>
            {
                if (double.TryParse(txtQty.Text, out double q))
                {
                    item.Quantity = q;
                    RedrawPreview();
                }
            };
            Grid.SetColumn(Labeled("Quantité", txtQty), 0);
            row.Children.Add(Labeled("Quantité", txtQty));

            var txtUnit = new TextBox
            {
                Text = item.UnitPrice.ToString("N2"),
                Height = 38,
                Padding = new Thickness(10, 0, 10, 0)
            };
            txtUnit.TextChanged += (s, e) =>
            {
                if (double.TryParse(txtUnit.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out double u))
                {
                    item.UnitPrice = u;
                    RedrawPreview();
                }
            };
            Grid.SetColumn(Labeled("Prix unitaire (DA)", txtUnit), 2);
            row.Children.Add(Labeled("Prix unitaire (DA)", txtUnit));

            var txtTotal = new TextBox
            {
                Text = item.Total.ToString("N2"),
                IsReadOnly = true,
                Background = (Brush)new BrushConverter().ConvertFrom("#F3F4F6")!,
                Height = 38,
                Padding = new Thickness(10, 0, 10, 0)
            };
            Grid.SetColumn(Labeled("Total TTC", txtTotal), 4);
            row.Children.Add(Labeled("Total TTC", txtTotal));

            Grid.SetRow(row, 2);
            g.Children.Add(row);
            b.Child = g;
            return b;
        }

        private TextBlock MakeFormLabel(string text)
        {
            return new TextBlock
            {
                Text = text,
                FontSize = 15,
                FontWeight = FontWeights.SemiBold,
                Foreground = (Brush)new BrushConverter().ConvertFrom("#1F2937")!,
                Margin = new Thickness(0, 0, 0, 16)
            };
        }

        private Grid RowTwo(UIElement left, UIElement right)
        {
            var g = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(20) });
            g.ColumnDefinitions.Add(new ColumnDefinition());
            Grid.SetColumn(left, 0);
            g.Children.Add(left);
            Grid.SetColumn(right, 2);
            g.Children.Add(right);
            return g;
        }

        private StackPanel Labeled(string label, Control input)
        {
            var s = new StackPanel();
            s.Children.Add(new TextBlock
            {
                Text = label,
                FontSize = 12,
                Foreground = _cGray,
                Margin = new Thickness(0, 0, 0, 6)
            });
            input.BorderBrush = (Brush)new BrushConverter().ConvertFrom("#E5E7EB")!;
            input.BorderThickness = new Thickness(1);
            s.Children.Add(input);
            return s;
        }

        private void FormField_Changed(object sender, EventArgs e)
        {
            if (sender is TextBox tb && tb.Tag is string tag)
            {
                switch (tag)
                {
                    case "DocumentNumber":
                        _currentDocument.DocumentNumber = tb.Text;
                        break;
                    case "ServicePeriod":
                        _currentDocument.ServicePeriod = tb.Text;
                        break;
                    case "PaymentTerms":
                        _currentDocument.PaymentTerms = tb.Text;
                        break;
                    case "Notes":
                        _currentDocument.Notes = tb.Text;
                        break;
                    case "TvaRate":
                        if (decimal.TryParse(tb.Text, out decimal tva))
                            _currentDocument.TvaRate = tva;
                        break;
                }
            }
            else if (sender is DatePicker dp && dp.Tag is string dpTag)
            {
                switch (dpTag)
                {
                    case "IssueDate":
                        if (dp.SelectedDate.HasValue)
                            _currentDocument.IssueDate = dp.SelectedDate.Value;
                        break;
                    case "DueDate":
                        if (dp.SelectedDate.HasValue)
                            _currentDocument.DueDate = dp.SelectedDate.Value;
                        break;
                }
            }
            RedrawPreview();
        }

        private void CmbDocumentType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FormContentPanel == null) return;

            if (CmbDocumentType.SelectedItem is ComboBoxItem ci)
            {
                _documentType = ci.Content?.ToString() == "NOTE D'HONORAIRES"
                    ? "NOTE_HONORAIRES"
                    : "RAPPORT_SPECIAL";
                RenderFormForDocumentType();
                RedrawPreview();
            }
        }

        private void CmbClient_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PreviewCanvas == null) return;

            if (CmbClient.SelectedItem is Client cl)
            {
                _selectedClientId = cl.Id.ToString();
                RedrawPreview();
            }
        }

        private void CmbTheme_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PreviewCanvas == null) return;

            if (CmbTheme.SelectedItem is ComboBoxItem ti && ti.Content != null)
            {
                _selectedTheme = ti.Content.ToString()!.Split(' ').FirstOrDefault() ?? "BlueWave";
                RedrawPreview();
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show("Document enregistré!", "Succès", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur: {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new System.Windows.Controls.PrintDialog();
                if (dlg.ShowDialog() == true)
                    dlg.PrintVisual(PreviewContainer, "Document");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur: {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnDownload_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBox.Show("Export Word en développement.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur: {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static double Mm(double mm) => mm / 25.4 * 96.0;

        private void RedrawPreview()
        {
            if (PreviewCanvas == null) return;

            PreviewCanvas.Children.Clear();
            PreviewCanvas.Width = Mm(210);
            PreviewCanvas.Height = Mm(297);

            DrawHeader();
            DrawFirmAndClientBoxes();

            if (_documentType == "NOTE_HONORAIRES")
            {
                DrawNoteTable();
                DrawTotalsAndFooter();
            }
            else
            {
                DrawRapportContent();
            }
        }

        private void DrawHeader()
        {
            var header = new Rectangle
            {
                Width = PreviewCanvas.Width,
                Height = Mm(45),
                Fill = _cDark
            };
            Canvas.SetLeft(header, 0);
            Canvas.SetTop(header, 0);
            PreviewCanvas.Children.Add(header);

            try
            {
                var wavePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "wave-header-01.svg");
                if (File.Exists(wavePath))
                {
                    var img = new Image
                    {
                        Width = PreviewCanvas.Width,
                        Height = Mm(45),
                        Stretch = Stretch.Fill,
                        Opacity = 0.3
                    };
                    var bi = new BitmapImage();
                    bi.BeginInit();
                    bi.UriSource = new Uri(wavePath, UriKind.Absolute);
                    bi.EndInit();
                    img.Source = bi;
                    Canvas.SetLeft(img, 0);
                    Canvas.SetTop(img, 0);
                    PreviewCanvas.Children.Add(img);
                }
            }
            catch { }

            var firmName = MakeText(
                _firmSettings?.CabinetName ?? "MME KEBAILI AMAL\nCOMMISSAIRE AUX COMPTES\nCOMPTABLES AGREE",
                10.5,
                Brushes.White,
                FontWeights.SemiBold
            );
            firmName.TextAlignment = TextAlignment.Left;
            Canvas.SetLeft(firmName, Mm(22));
            Canvas.SetTop(firmName, Mm(14));
            PreviewCanvas.Children.Add(firmName);

            var title = MakeText(
                _documentType == "NOTE_HONORAIRES" ? "NOTE D'HONORAIRES" : "RAPPORT SPECIAL",
                12,
                Brushes.White,
                FontWeights.SemiBold
            );
            Canvas.SetLeft(title, Mm(115));
            Canvas.SetTop(title, Mm(10));
            PreviewCanvas.Children.Add(title);

            var sub = MakeText(_currentDocument.DocumentNumber, 10.5, Brushes.White, FontWeights.SemiBold);
            Canvas.SetLeft(sub, Mm(115));
            Canvas.SetTop(sub, Mm(18));
            PreviewCanvas.Children.Add(sub);

            var dateTxt = MakeText($"ALGER LE {DateTime.Today:dd/MM/yyyy}", 9, Brushes.White, FontWeights.Normal);
            Canvas.SetLeft(dateTxt, Mm(115));
            Canvas.SetTop(dateTxt, Mm(27));
            PreviewCanvas.Children.Add(dateTxt);
        }

        private void DrawFirmAndClientBoxes()
        {
            double top = Mm(55);
            double left = Mm(20);
            double boxW = Mm(80);
            double boxH = Mm(35);

            var firmBorder = Box(left, top, boxW, boxH);
            PreviewCanvas.Children.Add(firmBorder);

            var firmTitle = MakeText(
                "MME KEBAILI AMEL\nCOMMISSAIRE AUX COMPTES\nCOMPTABLES AGREE",
                8.8,
                _cTeal,
                FontWeights.SemiBold
            );
            Canvas.SetLeft(firmTitle, left + Mm(3));
            Canvas.SetTop(firmTitle, top + Mm(2));
            PreviewCanvas.Children.Add(firmTitle);

            var firmInfo = MakeText(
                $"ADRESSE {_firmSettings?.Address ?? "CITE 13 HECTARS 96 LOGTS N°10 BARAKI"}\n" +
                $"NIF N°{_firmSettings?.Nif ?? "27716050093014741680"}\n" +
                $"NIS N°{_firmSettings?.Nis ?? "27716050093014741680"}\n" +
                $"AI N°{_firmSettings?.Ai ?? "16149780121"}",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            Canvas.SetLeft(firmInfo, left + Mm(3));
            Canvas.SetTop(firmInfo, top + Mm(13));
            PreviewCanvas.Children.Add(firmInfo);

            var cLeft = left + boxW + Mm(12);
            var clientBorder = Box(cLeft, top, boxW, boxH);
            PreviewCanvas.Children.Add(clientBorder);

            var clientTitle = MakeText("DOIT:", 8.8, _cTeal, FontWeights.SemiBold);
            Canvas.SetLeft(clientTitle, cLeft + Mm(3));
            Canvas.SetTop(clientTitle, top + Mm(2));
            PreviewCanvas.Children.Add(clientTitle);

            var selectedClient = _clients.FirstOrDefault(c => c.Id.ToString() == _selectedClientId);
            var clientInfo = MakeText(
                selectedClient != null
                    ? $"{selectedClient.Name}\n" +
                      $"ADRESSE {selectedClient.Address}\n" +
                      $"RC N°{selectedClient.Rc}\n" +
                      $"NIF N°{selectedClient.Nif}\n" +
                      $"NIS N°{selectedClient.Nis}\n" +
                      $"AI N°{selectedClient.Ai ?? "16149780121"}"
                    : "SARL DEFI CAR\n" +
                      "ADRESSE 44 RUE ABOU NOUAS HYDRA\n" +
                      "RC N°16/00-0988754B11\n" +
                      "NIF N°001116098875426\n" +
                      "NIS N°001116030281752\n" +
                      "AI N°16149780121",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            Canvas.SetLeft(clientInfo, cLeft + Mm(3));
            Canvas.SetTop(clientInfo, top + Mm(7));
            PreviewCanvas.Children.Add(clientInfo);
        }

        private void DrawNoteTable()
        {
            double left = Mm(20);
            double top = Mm(100);

            var headerBar = new Rectangle
            {
                Width = Mm(170),
                Height = Mm(10),
                Fill = _cTeal
            };
            Canvas.SetLeft(headerBar, left);
            Canvas.SetTop(headerBar, top);
            PreviewCanvas.Children.Add(headerBar);

            var hdrText = MakeText("DÉSIGNATION", 9, Brushes.White, FontWeights.SemiBold);
            Canvas.SetLeft(hdrText, left + Mm(3));
            Canvas.SetTop(hdrText, top + Mm(2));
            PreviewCanvas.Children.Add(hdrText);

            var mtText = MakeText("MT TTC", 9, Brushes.White, FontWeights.SemiBold);
            Canvas.SetLeft(mtText, left + Mm(155));
            Canvas.SetTop(mtText, top + Mm(2));
            PreviewCanvas.Children.Add(mtText);

            double rowY = top + Mm(12);
            foreach (var item in _currentDocument.LineItems)
            {
                var desc = MakeText(item.Description, 8.5, Brushes.Black, FontWeights.Normal);
                Canvas.SetLeft(desc, left + Mm(3));
                Canvas.SetTop(desc, rowY);
                PreviewCanvas.Children.Add(desc);

                var amount = MakeText(item.Total.ToString("N0"), 8.5, Brushes.Black, FontWeights.Normal);
                amount.TextAlignment = TextAlignment.Right;
                amount.Width = Mm(30);
                Canvas.SetLeft(amount, left + Mm(155));
                Canvas.SetTop(amount, rowY);
                PreviewCanvas.Children.Add(amount);

                rowY += Mm(7);
            }

            var totalBar = new Rectangle
            {
                Width = Mm(170),
                Height = Mm(8),
                Fill = (Brush)new BrushConverter().ConvertFrom("#E5E7EB")!
            };
            Canvas.SetLeft(totalBar, left);
            Canvas.SetTop(totalBar, rowY);
            PreviewCanvas.Children.Add(totalBar);

            var totalLbl = MakeText("TOTAL", 9, Brushes.Black, FontWeights.SemiBold);
            Canvas.SetLeft(totalLbl, left + Mm(3));
            Canvas.SetTop(totalLbl, rowY + Mm(1.5));
            PreviewCanvas.Children.Add(totalLbl);

            var totalVal = MakeText(
                _currentDocument.LineItems.Sum(li => li.Total).ToString("N0"),
                9,
                Brushes.Black,
                FontWeights.SemiBold
            );
            totalVal.TextAlignment = TextAlignment.Right;
            totalVal.Width = Mm(30);
            Canvas.SetLeft(totalVal, left + Mm(155));
            Canvas.SetTop(totalVal, rowY + Mm(1.5));
            PreviewCanvas.Children.Add(totalVal);
        }

        private void DrawTotalsAndFooter()
        {
            double left = Mm(20);
            double top = Mm(240);

            var sigLbl = MakeText(
                $"MME KEBAILI AMEL\nCOMMISSAIRE AUX COMPTES",
                8.5,
                Brushes.Black,
                FontWeights.Normal
            );
            Canvas.SetLeft(sigLbl, left + Mm(120));
            Canvas.SetTop(sigLbl, top);
            PreviewCanvas.Children.Add(sigLbl);
        }

        private void DrawRapportContent()
        {
            double left = Mm(20);
            double top = Mm(100);

            var bar = new Rectangle
            {
                Width = Mm(170),
                Height = Mm(8),
                Fill = _cTeal
            };
            Canvas.SetLeft(bar, left);
            Canvas.SetTop(bar, top);
            PreviewCanvas.Children.Add(bar);

            var t = MakeText(
                "RAPPORT SPECIAL PROJET D'AUGMENTATION DU CAPITAL SOCIAL",
                8.5,
                Brushes.White,
                FontWeights.SemiBold
            );
            Canvas.SetLeft(t, left + Mm(3));
            Canvas.SetTop(t, top + Mm(1.3));
            PreviewCanvas.Children.Add(t);

            double curY = top + Mm(12);

            var preambule = MakeText("PREAMBULE :", 9, Brushes.Black, FontWeights.SemiBold);
            Canvas.SetLeft(preambule, left);
            Canvas.SetTop(preambule, curY);
            PreviewCanvas.Children.Add(preambule);

            curY += Mm(7);

            var preambuleTxt = MakeText(
                "Faisant suite à votre demande relative à l'établissement par nos soins, en qualité de commissaire aux comptes de la SARL DEFI CAR, un rapport spécial lié à la résolution adoptée par l'assemblée général extraordinaires en date du 30 octobre 2025 inhérente à :",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            preambuleTxt.Width = Mm(170);
            Canvas.SetLeft(preambuleTxt, left);
            Canvas.SetTop(preambuleTxt, curY);
            PreviewCanvas.Children.Add(preambuleTxt);

            curY += Mm(18);

            var augTxt = MakeText(
                "L'augmentation du capital par l'incorporation du compte courant associé de sorte à porter le capital de 200 000 000DA (DEUX CENT MILLION DE DINARS) à 400 000 000DA (QUATRE CENT MILLION DE DINARS), nous avons l'opinion de vous exposer, ci-après notre opinion :",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            augTxt.Width = Mm(170);
            Canvas.SetLeft(augTxt, left);
            Canvas.SetTop(augTxt, curY);
            PreviewCanvas.Children.Add(augTxt);

            curY += Mm(20);

            var exposeTitle = MakeText("EXPOSE DES MOTIFS :", 9, Brushes.Black, FontWeights.SemiBold);
            Canvas.SetLeft(exposeTitle, left);
            Canvas.SetTop(exposeTitle, curY);
            PreviewCanvas.Children.Add(exposeTitle);

            curY += Mm(7);

            var exposeTxt = MakeText(
                "Dans le cadre de la mise en œuvre de sa stratégie de développement, l'augmentation du capital social de la SARL DEFI CAR constitue une étape importante pour concrétiser sa politique commerciale.",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            exposeTxt.Width = Mm(170);
            Canvas.SetLeft(exposeTxt, left);
            Canvas.SetTop(exposeTxt, curY);
            PreviewCanvas.Children.Add(exposeTxt);

            curY += Mm(12);

            var exposeTxt2 = MakeText(
                "En effet, avec l'évolution de son actif, il serait plus judicieux d'asseoir des fonds propres permanents à même de dégager un fonds de roulement performant.",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            exposeTxt2.Width = Mm(170);
            Canvas.SetLeft(exposeTxt2, left);
            Canvas.SetTop(exposeTxt2, curY);
            PreviewCanvas.Children.Add(exposeTxt2);

            curY += Mm(15);

            var tableTitle = MakeText(
                "TABLEAU D'EVOLUTION DU CAPITAL SOCIAL :",
                8.5,
                _cTeal,
                FontWeights.SemiBold
            );
            Canvas.SetLeft(tableTitle, left);
            Canvas.SetTop(tableTitle, curY);
            PreviewCanvas.Children.Add(tableTitle);

            curY += Mm(7);
            DrawRapportTable(left, curY);
            curY += Mm(30);

            var opinionTitle = MakeText(
                "OPINION SUR L'AUGMENTATION DU CAPITAL SOCIAL :",
                9,
                Brushes.Black,
                FontWeights.SemiBold
            );
            Canvas.SetLeft(opinionTitle, left);
            Canvas.SetTop(opinionTitle, curY);
            PreviewCanvas.Children.Add(opinionTitle);

            curY += Mm(7);

            var opinionTxt = MakeText(
                "Nous nous sommes assurés que les procédures suivies présentent un caractère équitable en vérifiant que les modalités de l'augmentation de capital proposée n'ont pas d'incidence sur le montant des capitaux propres et qu'elles sont conformes aux dispositions légales et réglementaires applicables.",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            opinionTxt.Width = Mm(170);
            Canvas.SetLeft(opinionTxt, left);
            Canvas.SetTop(opinionTxt, curY);
            PreviewCanvas.Children.Add(opinionTxt);

            curY += Mm(18);

            var conclusionTxt = MakeText(
                "En conséquence, nous émettons une opinion favorable sur les modalités et conditions de la présente opération d'augmentation du capital social.",
                8,
                Brushes.Black,
                FontWeights.Normal
            );
            conclusionTxt.Width = Mm(170);
            Canvas.SetLeft(conclusionTxt, left);
            Canvas.SetTop(conclusionTxt, curY);
            PreviewCanvas.Children.Add(conclusionTxt);

            curY += Mm(15);

            var dateLbl = MakeText(
                $"Fait à Alger, le {DateTime.Today:dd/MM/yyyy}",
                8.5,
                Brushes.Black,
                FontWeights.Normal
            );
            Canvas.SetLeft(dateLbl, left);
            Canvas.SetTop(dateLbl, curY);
            PreviewCanvas.Children.Add(dateLbl);

            curY += Mm(8);

            var sigLbl = MakeText(
                "MME KEBAILI AMEL\nCOMMISSAIRE AUX COMPTES",
                8.5,
                Brushes.Black,
                FontWeights.SemiBold
            );
            Canvas.SetLeft(sigLbl, left);
            Canvas.SetTop(sigLbl, curY);
            PreviewCanvas.Children.Add(sigLbl);
        }

        private void DrawRapportTable(double left, double top)
        {
            var tbl = new Grid { Width = Mm(170), Height = Mm(22) };
            Canvas.SetLeft(tbl, left);
            Canvas.SetTop(tbl, top);

            tbl.RowDefinitions.Add(new RowDefinition { Height = new GridLength(Mm(8)) });
            tbl.RowDefinitions.Add(new RowDefinition { Height = new GridLength(Mm(7)) });
            tbl.RowDefinitions.Add(new RowDefinition { Height = new GridLength(Mm(7)) });
            tbl.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Mm(85)) });
            tbl.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Mm(42.5)) });
            tbl.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Mm(42.5)) });

            var hdrBg = new Rectangle { Fill = _cTeal };
            Grid.SetRow(hdrBg, 0);
            Grid.SetColumnSpan(hdrBg, 3);
            tbl.Children.Add(hdrBg);

            var h1 = MakeText("Désignation", 8, Brushes.White, FontWeights.SemiBold);
            h1.VerticalAlignment = VerticalAlignment.Center;
            h1.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(h1, 0);
            Grid.SetColumn(h1, 0);
            tbl.Children.Add(h1);

            var h2 = MakeText("Avant augmentation", 8, Brushes.White, FontWeights.SemiBold);
            h2.VerticalAlignment = VerticalAlignment.Center;
            h2.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(h2, 0);
            Grid.SetColumn(h2, 1);
            tbl.Children.Add(h2);

            var h3 = MakeText("Après augmentation", 8, Brushes.White, FontWeights.SemiBold);
            h3.VerticalAlignment = VerticalAlignment.Center;
            h3.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(h3, 0);
            Grid.SetColumn(h3, 2);
            tbl.Children.Add(h3);

            var c1r1 = MakeText("Capital social (DA)", 8, Brushes.Black, FontWeights.Normal);
            c1r1.VerticalAlignment = VerticalAlignment.Center;
            c1r1.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(c1r1, 1);
            Grid.SetColumn(c1r1, 0);
            tbl.Children.Add(c1r1);

            var c2r1 = MakeText("200 000 000", 8, Brushes.Black, FontWeights.Normal);
            c2r1.VerticalAlignment = VerticalAlignment.Center;
            c2r1.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(c2r1, 1);
            Grid.SetColumn(c2r1, 1);
            tbl.Children.Add(c2r1);

            var c3r1 = MakeText("400 000 000", 8, Brushes.Black, FontWeights.Normal);
            c3r1.VerticalAlignment = VerticalAlignment.Center;
            c3r1.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(c3r1, 1);
            Grid.SetColumn(c3r1, 2);
            tbl.Children.Add(c3r1);

            var c1r2 = MakeText("Nombre de parts sociales", 8, Brushes.Black, FontWeights.Normal);
            c1r2.VerticalAlignment = VerticalAlignment.Center;
            c1r2.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(c1r2, 2);
            Grid.SetColumn(c1r2, 0);
            tbl.Children.Add(c1r2);

            var c2r2 = MakeText("20 000", 8, Brushes.Black, FontWeights.Normal);
            c2r2.VerticalAlignment = VerticalAlignment.Center;
            c2r2.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(c2r2, 2);
            Grid.SetColumn(c2r2, 1);
            tbl.Children.Add(c2r2);

            var c3r2 = MakeText("40 000", 8, Brushes.Black, FontWeights.Normal);
            c3r2.VerticalAlignment = VerticalAlignment.Center;
            c3r2.Margin = new Thickness(Mm(2), 0, 0, 0);
            Grid.SetRow(c3r2, 2);
            Grid.SetColumn(c3r2, 2);
            tbl.Children.Add(c3r2);

            var border = new Border
            {
                BorderBrush = _cBorder,
                BorderThickness = new Thickness(1),
                Child = tbl
            };
            Canvas.SetLeft(border, left);
            Canvas.SetTop(border, top);
            PreviewCanvas.Children.Add(border);

            for (int i = 0; i < 3; i++)
            {
                var v = new Rectangle
                {
                    Width = 1,
                    Height = Mm(22),
                    Fill = _cBorder
                };
                Canvas.SetLeft(v, left + Mm(85) + i * Mm(42.5));
                Canvas.SetTop(v, top);
                PreviewCanvas.Children.Add(v);
            }

            for (int i = 1; i < 3; i++)
            {
                var h = new Rectangle
                {
                    Width = Mm(170),
                    Height = 1,
                    Fill = _cBorder
                };
                Canvas.SetLeft(h, left);
                Canvas.SetTop(h, top + Mm(8) + (i - 1) * Mm(7));
                PreviewCanvas.Children.Add(h);
            }
        }

        private TextBlock MakeText(string text, double fontSize, Brush color, FontWeight weight)
        {
            return new TextBlock
            {
                Text = text,
                FontSize = fontSize,
                Foreground = color,
                FontWeight = weight,
                TextWrapping = TextWrapping.Wrap
            };
        }

        private Border Box(double left, double top, double width, double height)
        {
            var b = new Border
            {
                Width = width,
                Height = height,
                Background = Brushes.White,
                BorderBrush = _cBorder,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(3)
            };
            Canvas.SetLeft(b, left);
            Canvas.SetTop(b, top);
            return b;
        }
    }
}

