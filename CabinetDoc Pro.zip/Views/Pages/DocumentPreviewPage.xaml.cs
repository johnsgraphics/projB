﻿using System.Windows.Controls;

namespace CabinetDocProWpf.Views.Pages
{
    public partial class DocumentPreviewPage : Page
    {
        public DocumentPreviewPage()
        {
            InitializeComponent();
        }
    }
}
